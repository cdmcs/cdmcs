// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){b.ByteSizeUnit=void 0;var a=b.ByteSizeUnit||(b.ByteSizeUnit={});a[a.KILOBYTES=1024]="KILOBYTES";a[a.MEGABYTES=1048576]="MEGABYTES";a[a.GIGABYTES=1073741824]="GIGABYTES";Object.defineProperty(b,Symbol.toStringTag,{value:"Module"})});