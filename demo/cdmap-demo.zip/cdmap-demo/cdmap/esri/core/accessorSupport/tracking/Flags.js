// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){b.Flags=void 0;var a=b.Flags||(b.Flags={});a[a.Dirty=1]="Dirty";a[a.Overriden=2]="Overriden";a[a.Computing=4]="Computing";a[a.NonNullable=8]="NonNullable";a[a.HasDefaultValue=16]="HasDefaultValue";a[a.DepTrackingInitialized=32]="DepTrackingInitialized";a[a.AutoTracked=64]="AutoTracked";a[a.ExplicitlyTracking=128]="ExplicitlyTracking";Object.defineProperty(b,Symbol.toStringTag,{value:"Module"})});