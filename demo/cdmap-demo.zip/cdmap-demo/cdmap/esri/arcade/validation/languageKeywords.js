// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports","../lib/types"],function(a,b){b=Object.values(b.Keywords);a.ArcadeKeywords=b;a.ArcadeReservedKeywords=["case","catch","debugger","switch","try"];Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});