// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports","./loader"],function(a,b){const c=b.defineCustomElement;a.CalciteLoader=b.Loader;a.defineCustomElement=c;Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});