// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports"],function(c){function d(e){return e.map(f=>{let a="";for(let b=0;b<f;b++)a+=(65536*(1+Math.random())|0).toString(16).substring(1);return a}).join("-")}c.guid=()=>d([2,1,1,1,3])});