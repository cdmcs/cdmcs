// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports"],function(a){class b{constructor(c,d){this.preLayerQueryCallback=c;this.preRequestCallback=d;this.preLayerQueryCallback||(this.preLayerQueryCallback=e=>{});this.preRequestCallback||(this.preLayerQueryCallback=e=>{})}}a.FeatureSetQueryInterceptor=b;Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});