// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["./Dictionary"],function(a){class b extends a{constructor(c){super();this.declaredClass="esri.arcade.Portal";this.immutable=!1;this.setField("url",c);this.immutable=!0}}return b});