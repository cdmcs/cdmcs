// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(function(){class c{constructor(a=[]){this._elements=a}length(){return this._elements.length}get(a){return this._elements[a]}toArray(){const a=[];for(let b=0;b<this.length();b++)a.push(this.get(b));return a}}return c});