// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){let c;b.InterceptorCollectAction=void 0;(function(a){a[a.Ignore=0]="Ignore";a[a.Destroy=1]="Destroy";a[a.ThrowError=2]="ThrowError"})(b.InterceptorCollectAction||(b.InterceptorCollectAction={}));b.getAccessorInterceptor=function(){return c};b.setAccessorInterceptor=function(a){c=a};Object.defineProperty(b,Symbol.toStringTag,{value:"Module"})});