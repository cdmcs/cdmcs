// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports","./chip"],function(a,b){const c=b.defineCustomElement;a.CalciteChip=b.Chip;a.defineCustomElement=c;Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});