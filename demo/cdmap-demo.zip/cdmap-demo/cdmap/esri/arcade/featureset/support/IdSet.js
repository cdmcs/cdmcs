// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(function(){class a{constructor(b,c,d,e){this._lastFetchedIndex=0;this._ordered=!1;this.pagesDefinition=null;this._candidates=b;this._known=c;this._ordered=d;this.pagesDefinition=e}}return a});