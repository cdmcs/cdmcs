// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports"],function(d){function e(c,a){const f=c.count;a||(a=new c.TypedArrayConstructor(f));for(let b=0;b<f;b++)a[b]=c.get(b);return a}const g=Object.freeze(Object.defineProperty({__proto__:null,makeDense:e},Symbol.toStringTag,{value:"Module"}));d.makeDense=e;d.scalar=g});