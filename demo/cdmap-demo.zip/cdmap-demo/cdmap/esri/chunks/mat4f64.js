// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){function c(){return[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]}function e(a){return[a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],a[9],a[10],a[11],a[12],a[13],a[14],a[15]]}function f(a,d,k,l,m,n,p,q,r,t,u,v,w,x,y,z){return[a,d,k,l,m,n,p,q,r,t,u,v,w,x,y,z]}function g(a,d){return new Float64Array(a,d,16)}const h=c(),A=Object.freeze(Object.defineProperty({__proto__:null,IDENTITY:h,clone:e,create:c,createView:g,fromValues:f},Symbol.toStringTag,{value:"Module"}));b.IDENTITY=h;b.clone=
e;b.create=c;b.createView=g;b.fromValues=f;b.mat4f64=A});