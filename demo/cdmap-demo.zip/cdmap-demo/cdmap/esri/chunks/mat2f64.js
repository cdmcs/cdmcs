// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){function d(){return[1,0,0,1]}function e(a){return[a[0],a[1],a[2],a[3]]}function f(a,c,h,k){return[a,c,h,k]}function g(a,c){return new Float64Array(a,c,4)}const l=Object.freeze(Object.defineProperty({__proto__:null,clone:e,create:d,createView:g,fromValues:f},Symbol.toStringTag,{value:"Module"}));b.clone=e;b.create=d;b.createView=g;b.fromValues=f;b.mat2f64=l});