// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports","./has"],function(a,c){a.neverReached=function(b){};a.neverReachedSilent=function(b){};a.typeCast=function(b){return()=>b};Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});