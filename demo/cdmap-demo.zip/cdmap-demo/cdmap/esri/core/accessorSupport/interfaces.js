// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){b.Lifecycle=void 0;var a=b.Lifecycle||(b.Lifecycle={});a[a.INITIALIZING=0]="INITIALIZING";a[a.CONSTRUCTING=1]="CONSTRUCTING";a[a.CONSTRUCTED=2]="CONSTRUCTED";Object.defineProperty(b,Symbol.toStringTag,{value:"Module"})});