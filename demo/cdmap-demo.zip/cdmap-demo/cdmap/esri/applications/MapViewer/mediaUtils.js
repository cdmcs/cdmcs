// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports","../../layers/support/mediaUtils"],function(a,c){a.createDefaultControlPointsGeoreference=async function(b,d){return c.createDefaultControlPointsGeoreference(b,d)};a.createLocalModeControlPointsGeoreference=function(b){return c.createLocalModeControlPointsGeoreference(b)};Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});