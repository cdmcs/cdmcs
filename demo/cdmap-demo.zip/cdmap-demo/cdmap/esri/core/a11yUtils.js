// All material copyright Esri, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.28/esri/copyright.txt for details.
//>>built
define(["exports"],function(a){a.prefersReducedMotion=()=>window.matchMedia("(prefers-reduced-motion: reduce)").matches;Object.defineProperty(a,Symbol.toStringTag,{value:"Module"})});